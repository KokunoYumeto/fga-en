"""Render one authority-PDF page for direct source inspection.

Usage: python render.py INPUT.pdf PAGE OUTPUT.png [DPI]
PAGE is one-based.  This never performs OCR or modifies the authority PDF.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pypdfium2 as pdfium


def main() -> int:
    if len(sys.argv) not in (4, 5):
        raise SystemExit("usage: render.py INPUT.pdf PAGE OUTPUT.png [DPI]")

    source = Path(sys.argv[1]).resolve(strict=True)
    page_number = int(sys.argv[2])
    output = Path(sys.argv[3]).resolve()
    dpi = int(sys.argv[4]) if len(sys.argv) == 5 else 360
    if page_number < 1 or dpi < 72:
        raise SystemExit("PAGE must be >= 1 and DPI must be >= 72")

    document = pdfium.PdfDocument(source)
    if page_number > len(document):
        raise SystemExit(f"PAGE {page_number} exceeds {len(document)} pages")

    output.parent.mkdir(parents=True, exist_ok=True)
    page = document[page_number - 1]
    bitmap = page.render(scale=dpi / 72)
    bitmap.to_pil().save(output, format="PNG", optimize=True)
    page.close()
    document.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
