"""Build and validate the shared FGA semantic/reference scaffold."""

from __future__ import annotations

import bisect
import csv
import hashlib
import json
import re
import subprocess
import unicodedata
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ED = ROOT / "ed"
AUTH = ROOT.parents[1] / "01_recovered_witnesses" / "fga_numdam_canonical_intake_20260804"
AUTH_MANIFEST_SHA256 = "30AB17BCB74755DD36F6C95463043CD049680C3CCDFEF883CAC3240DF0A566ED"
AUTH_VALIDATION_SHA256 = "85960D5F61FBCF39706DAB7F9DC6487E38CA12403557AAAB7B80F536B73B20DB"
KEYS = [
    "149", "e149", "182", "e182", "190", "e190", "195", "e195",
    "212", "e212", "221", "e221", "232", "e232", "236", "e236", "com",
]
RESULT_TYPES = {
    "THÉORÈME": "theorem", "THEOREM": "theorem",
    "PROPOSITION": "proposition",
    "COROLLAIRE": "corollary", "COROLLARY": "corollary",
    "LEMME": "lemma", "LEMMA": "lemma",
    "DÉFINITION": "definition", "DEFINITION": "definition",
    "REMARQUE": "remark", "REMARQUES": "remark",
    "REMARK": "remark", "REMARKS": "remark",
}
TYPE_FR = {
    "theorem": "Théorème", "proposition": "Proposition", "corollary": "Corollaire",
    "lemma": "Lemme", "definition": "Définition", "remark": "Remarque",
}
TYPE_EN = {key: key.title() for key in TYPE_FR}
EXTERNAL = {
    "EGA": ("ext.ega", "Éléments de géométrie algébrique"),
    "SGA": ("ext.sga", "Séminaire de géométrie algébrique"),
    "SHG": ("ext.shg", "Séminaire Grothendieck, Harvard"),
    "SHMT": ("ext.shmt", "Séminaire Mumford–Tate, Harvard"),
    "TDTE": ("ext.tdte", "Technique de descente et théorèmes d'existence"),
}


CONCEPTS = [
    ("coherent-sheaf", "Coherent sheaf", r"faisceaux? (?:algébriques )?cohérents?", r"coherent (?:algebraic )?sheaves?"),
    ("ext-functor", "Ext functor", r"\bExt\b|foncteurs? Ext", r"\bExt\b|Ext functors?"),
    ("local-cohomology", "Local cohomology", r"cohomologie locale", r"local cohomology"),
    ("duality", "Duality", r"dualité", r"duality"),
    ("dualizing-sheaf", "Dualizing sheaf", r"faisceau dualisant|faisceau canonique", r"dualizing sheaf|canonical sheaf"),
    ("fundamental-class", "Fundamental class", r"classe fondamentale", r"fundamental class"),
    ("poincare-duality", "Poincaré duality", r"dualité de Poincaré", r"Poincaré duality"),
    ("formal-geometry", "Formal geometry", r"géométrie formelle", r"formal geometry"),
    ("formal-scheme", "Formal scheme", r"schémas? formels?", r"formal schemes?"),
    ("formal-completion", "Formal completion", r"complété formel|complétion formelle", r"formal completion"),
    ("algebraization", "Algebraization", r"algébrisation|algébriser", r"algebraization|algebraize"),
    ("existence-theorem", "Existence theorem", r"théorème d.existence", r"existence theorem"),
    ("descent", "Descent", r"descente", r"descent"),
    ("faithfully-flat", "Faithfully flat morphism", r"fidèlement plat", r"faithfully flat"),
    ("descent-datum", "Descent datum", r"donnée de descente", r"descent datum|descent data"),
    ("effectivity", "Effectivity", r"effectivit[ée]|effective", r"effectivity|effective"),
    ("quotient", "Quotient", r"quotient", r"quotient"),
    ("equivalence-relation", "Equivalence relation", r"relation d.équivalence", r"equivalence relation"),
    ("representability", "Representability", r"représentable|représente le foncteur", r"representable|represents the functor"),
    ("hilbert-functor", "Hilbert functor", r"foncteur de Hilbert", r"Hilbert functor"),
    ("hilbert-scheme", "Hilbert scheme", r"schémas? de Hilbert", r"Hilbert schemes?"),
    ("picard-functor", "Picard functor", r"foncteur de Picard", r"Picard functor"),
    ("picard-scheme", "Picard scheme", r"schémas? de Picard|Pic", r"Picard schemes?|Pic"),
    ("cartier-divisor", "Cartier divisor", r"diviseurs? de Cartier", r"Cartier divisors?"),
    ("invertible-module", "Invertible Module", r"Modules? inversibles?", r"invertible Modules?"),
    ("poincare-bundle", "Poincaré bundle", r"faisceau de Poincaré|Module de Poincaré", r"Poincaré sheaf|Poincaré Module"),
    ("albanese", "Albanese scheme", r"Albanese", r"Albanese"),
    ("abelian-scheme", "Abelian scheme", r"schémas? abéliens?", r"abelian schemes?"),
    ("neron-severi", "Néron–Severi group", r"Néron.?Severi", r"Néron.?Severi"),
    ("hilbert-polynomial", "Hilbert polynomial", r"polynômes? de Hilbert", r"Hilbert polynomials?"),
    ("flatness", "Flatness", r"platitude|\bplat\b|\bplate\b", r"flatness|\bflat\b"),
    ("properness", "Properness", r"\bpropre\b|\bpropres\b", r"\bproper\b"),
    ("smoothness", "Smoothness", r"\bsimple\b|\bsimples\b|non singuli", r"\bsmooth\b|nonsingular"),
    ("separatedness", "Separatedness", r"\bséparé\b|\bséparée\b|séparation", r"\bseparated\b|separatedness"),
    ("projectivity", "Projectivity", r"projectif|projective", r"projective|projectivity"),
    ("quasi-projectivity", "Quasi-projectivity", r"quasi.projectif", r"quasi.projective"),
    ("ampleness", "Ampleness", r"\bample\b|amplitude", r"\bample\b|ampleness"),
    ("finite-type", "Finite type", r"type fini", r"finite type"),
    ("connected-component", "Connected component", r"composante connexe", r"connected component"),
    ("group-scheme", "Group scheme", r"schémas? en groupes?", r"group schemes?"),
    ("etale", "Étale morphism", r"étale", r"étale"),
    ("fundamental-group", "Fundamental group", r"groupe fondamental", r"fundamental group"),
    ("galois-cover", "Galois covering", r"revêtements? galoisiens?", r"Galois coverings?"),
    ("tame-ramification", "Tame ramification", r"modérément ramifi|tame", r"tamely ramified|tame ramification"),
    ("frobenius-radicial", "Frobenius and radicial morphisms", r"Frobenius|radiciel", r"Frobenius|radicial"),
    ("normality", "Normality", r"normalité|\bnormal\b|\bnormale\b", r"normality|\bnormal\b"),
    ("serre-s2", "Serre condition S2", r"propriété \(S_2\)|condition \(S_2\)", r"condition \(S_2\)|property \(S_2\)"),
    ("boundedness", "Boundedness", r"borné|bornée|limité|limitée", r"bounded|boundedness"),
    ("numerical-equivalence", "Numerical equivalence", r"équivalence numérique", r"numerical equivalence"),
    ("algebraic-equivalence", "Algebraic equivalence", r"équivalence algébrique", r"algebraic equivalence"),
    ("torsion-equivalence", "Torsion equivalence", r"équivalence .de torsion.|τ.équivalent", r"torsion equivalence|τ.equivalent"),
    ("euler-characteristic", "Euler–Poincaré characteristic", r"Euler.?Poincaré|caractéristique χ", r"Euler.?Poincaré|characteristic χ"),
    ("base-change", "Base change", r"changement de base", r"base change"),
    ("formal-functions", "Formal functions", r"fonctions formelles", r"formal functions"),
    ("cohomology", "Cohomology", r"cohomologie", r"cohomology"),
]


@dataclass
class Event:
    kind: str
    pos: int
    end: int
    label: str = ""
    title: str = ""
    raw_type: str = ""
    body_end: int = 0
    uid: str = ""
    parent: str = ""


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def save_text(path: Path, text: str) -> None:
    path.write_text(text, encoding="utf-8", newline="\n")


def save_json(path: Path, value: object) -> None:
    save_text(path, json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def save_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, lineterminator="\n", extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def slug(value: str) -> str:
    value = value.replace("*", "star").replace("+", "plus").replace("'", "prime")
    value = unicodedata.normalize("NFKD", value)
    value = "".join(ch for ch in value if not unicodedata.combining(ch))
    value = re.sub(r"[^A-Za-z0-9]+", "-", value).strip("-").lower()
    return value or "u"


def read_group(text: str, pos: int, opening: str = "{", closing: str = "}") -> tuple[str, int]:
    if pos >= len(text) or text[pos] != opening:
        raise ValueError(f"Expected {opening!r} at {pos}")
    depth = 1
    i = pos + 1
    while i < len(text):
        ch = text[i]
        if ch == "\\":
            i += 2
            continue
        if ch == opening:
            depth += 1
        elif ch == closing:
            depth -= 1
            if depth == 0:
                return text[pos + 1:i], i + 1
        i += 1
    raise ValueError(f"Unclosed group at {pos}")


def macro_calls(text: str, name: str, nargs: int) -> list[tuple[int, int, list[str]]]:
    rows = []
    for match in re.finditer(r"\\" + re.escape(name) + r"(?![A-Za-z])", text):
        pos = match.end()
        args = []
        try:
            for _ in range(nargs):
                while pos < len(text) and text[pos].isspace():
                    pos += 1
                arg, pos = read_group(text, pos)
                args.append(arg)
        except ValueError:
            continue
        rows.append((match.start(), pos, args))
    return rows


def plain(value: str) -> str:
    value = re.sub(r"%.*", " ", value)
    for _ in range(3):
        value = re.sub(r"\\(?:operatorname|text|emph|textbf|textit)\{([^{}]*)\}", r"\1", value)
    value = re.sub(r"\\textsuperscript\{([^{}]*)\}", r"\1", value)
    value = value.replace("---", "—").replace("--", "–").replace("~", " ")
    value = re.sub(r"\\[A-Za-z@]+\*?", " ", value)
    value = re.sub(r"[{}$]", " ", value)
    value = value.replace("\\&", "&").replace("\\%", "%")
    return re.sub(r"\s+", " ", value).strip()


def snippet(text: str, start: int, end: int, limit: int = 220) -> str:
    value = plain(text[start:min(end, start + 1400)])
    return value[:limit].rstrip()


def line_starts(text: str) -> list[int]:
    return [0] + [match.end() for match in re.finditer("\n", text)]


def line_at(starts: list[int], pos: int) -> int:
    return bisect.bisect_right(starts, pos)


def item_label(text: str, pos: int) -> tuple[str, int]:
    i = pos
    while i < len(text) and text[i].isspace():
        i += 1
    if i < len(text) and text[i] == "[":
        try:
            content, end = read_group(text, i, "[", "]")
            number = re.search(r"\[([0-9]+)\]", content)
            return (number.group(1) if number else plain(content), end)
        except ValueError:
            pass
    return "", i


def parse_events(text: str, key: str) -> tuple[list[Event], list[tuple[int, int]]]:
    events: list[Event] = []
    pages = [(pos, int(args[0])) for pos, _end, args in macro_calls(text, "src", 1)]

    for pos, end, args in macro_calls(text, "fsection", 2):
        events.append(Event("section", pos, end, args[0], plain(args[1])))

    for match in re.finditer(r"\\section\*\s*", text):
        try:
            title, end = read_group(text, match.end())
        except ValueError:
            continue
        folded = plain(title).casefold()
        kind = "bibliography_section" if "bibliograph" in folded else (
            "supplement_section" if "additif" in folded or "addendum" in folded else "section"
        )
        events.append(Event(kind, match.start(), end, "", plain(title)))

    for match in re.finditer(r"\\textbf\{BIBLIOGRAPH(?:IE|Y)\}", text, re.I):
        if not any(ev.kind == "bibliography_section" and abs(ev.pos - match.start()) < 180 for ev in events):
            events.append(Event("bibliography_section", match.start(), match.end(), "", "Bibliographie"))

    for pos, end, args in macro_calls(text, "result", 2):
        raw = plain(args[0]).upper()
        kind = RESULT_TYPES.get(raw, "result")
        full_label = plain(args[1])
        numbered = re.match(r"^([0-9]+(?:\.[0-9]+)?(?:\s*bis)?)(?:\.\s*|\s+)?(.*)$", full_label, re.I)
        label = numbered.group(1) if numbered else full_label
        title = numbered.group(2) if numbered else ""
        events.append(Event(kind, pos, end, label, title, raw))

    display_spans: list[tuple[int, int]] = []
    env_re = re.compile(r"\\begin\{(equation|align\*?|gather\*?|multline\*?)\}")
    for match in env_re.finditer(text):
        env = match.group(1)
        close = re.search(r"\\end\{" + re.escape(env) + r"\}", text[match.end():])
        if close is None:
            continue
        end = match.end() + close.end()
        body = text[match.end():end]
        tag_match = re.search(r"\\tag\{([^{}]+)\}", body)
        label = plain(tag_match.group(1)) if tag_match else ""
        events.append(Event("equation", match.start(), end, label, env))
        display_spans.append((match.start(), end))
    for match in re.finditer(r"\\\[", text):
        if any(start <= match.start() < end for start, end in display_spans):
            continue
        close = text.find(r"\]", match.end())
        if close < 0:
            continue
        end = close + 2
        body = text[match.end():close]
        tag_match = re.search(r"\\tag\{([^{}]+)\}", body)
        events.append(Event("equation", match.start(), end, plain(tag_match.group(1)) if tag_match else "", "display"))
        display_spans.append((match.start(), end))

    for match in re.finditer(r"\\begin\{(array|CD)\}", text):
        env = match.group(1)
        close = re.search(r"\\end\{" + env + r"\}", text[match.end():])
        if close is None:
            continue
        end = match.end() + close.end()
        body = text[match.end():end]
        if env == "CD" or (re.search(r"\\(?:long)?(?:right|left)?arrow|\\to|\\downarrow|\\uparrow", body) and r"\\" in body):
            events.append(Event("diagram", match.start(), end, "", "native TeX diagram"))

    for match in re.finditer(r"\\item(?![A-Za-z])", text):
        label, end = item_label(text, match.end())
        events.append(Event("item", match.start(), end, label, ""))

    for match in re.finditer(r"\\noindent\s*\[([0-9]+)\]", text):
        events.append(Event("bibliography_item", match.start(), match.end(), match.group(1), ""))

    if key.startswith("e"):
        for pos, end, args in macro_calls(text, "textbf", 1):
            prefix = text[max(0, pos - 20):pos]
            if r"\noindent" in prefix:
                events.append(Event("item", pos, end, "", plain(args[0])))

    manual = re.compile(r"(?m)^\s*(?:\\noindent\s*)?([a-h](?:['’])?\.|[0-9]+\))\s+")
    for match in manual.finditer(text):
        events.append(Event("item", match.start(), match.end(), plain(match.group(1)), ""))
    # Numbered assertions in the edition are introduced by \noindent. A bare
    # parenthetical roman numeral inside prose is a cross-reference, not a new
    # semantic subitem, and the translations need not repeat it verbatim.
    for match in re.finditer(
        r"(?m)^\s*\\noindent\s*(\((?:i|ii|iii|iv|v|vi|vii|viii|ix)\))\s+",
        text,
    ):
        events.append(Event("item", match.start(), match.end(), plain(match.group(1)), ""))

    unique: dict[tuple[int, str], Event] = {}
    for event in events:
        unique.setdefault((event.pos, event.kind), event)
    events = sorted(unique.values(), key=lambda ev: (ev.pos, 0 if "section" in ev.kind else 1))
    return events, pages


def event_signature(events: list[Event]) -> list[tuple[str, str]]:
    counts: Counter[str] = Counter()
    rows = []
    for event in events:
        counts[event.kind] += 1
        label = slug(event.label) if event.kind in {
            "section", "theorem", "proposition", "corollary", "lemma", "definition",
            "remark", "result", "equation", "bibliography_item",
        } else str(counts[event.kind])
        rows.append((event.kind, label))
    return rows


def current_page(pages: list[tuple[int, int]], pos: int) -> int:
    positions = [row[0] for row in pages]
    index = bisect.bisect_right(positions, pos) - 1
    return pages[max(index, 0)][1]


def source_span(pages: list[tuple[int, int]], start: int, end: int) -> tuple[int, int]:
    values = [current_page(pages, start)]
    values.extend(page for pos, page in pages if start < pos < end)
    return values[0], values[-1]


def catalog_pages(value: str) -> list[int]:
    nums = [int(number) for number in re.findall(r"[0-9]+", value)]
    if len(nums) == 1:
        return nums
    return list(range(nums[0], nums[-1] + 1))


def main() -> int:
    if sha256(AUTH / "SOURCE_FILES.csv") != AUTH_MANIFEST_SHA256:
        raise RuntimeError("Authority manifest identity changed")
    if sha256(AUTH / "VALIDATION.json") != AUTH_VALIDATION_SHA256:
        raise RuntimeError("Authority validation identity changed")
    with (AUTH / "SOURCE_FILES.csv").open(encoding="utf-8", newline="") as handle:
        auth_rows = list(csv.DictReader(handle))
    authority: dict[str, dict[str, str]] = {}
    for row in auth_rows:
        key = "com" if row["class"] == "commentaires" else (
            ("e" if row["class"] == "erratum" else "") + row["corrects_expose"]
        )
        authority[key] = row
        if sha256(AUTH / row["local_filename"]) != row["sha256"]:
            raise RuntimeError(f"Authority file identity changed: {row['local_filename']}")
    if set(authority) != set(KEYS):
        raise RuntimeError("Authority/key allocation differs")

    texts: dict[tuple[str, str], str] = {}
    parsed: dict[tuple[str, str], tuple[list[Event], list[tuple[int, int]]]] = {}
    starts: dict[tuple[str, str], list[int]] = {}
    residuals: list[dict[str, object]] = []
    units: list[dict[str, object]] = []
    internal: dict[str, dict[str, object]] = {}
    order_map = {key: index for index, key in enumerate(KEYS)}

    for key in KEYS:
        for lang in ("fr", "en"):
            path = ROOT / lang / f"{key}.tex"
            text = path.read_text(encoding="utf-8")
            texts[(key, lang)] = text
            parsed[(key, lang)] = parse_events(text, key)
            starts[(key, lang)] = line_starts(text)
        fr_events, fr_pages = parsed[(key, "fr")]
        en_events, en_pages = parsed[(key, "en")]
        if [page for _pos, page in fr_pages] != [page for _pos, page in en_pages]:
            raise RuntimeError(f"Source-page alignment differs: {key}")
        if event_signature(fr_events) != event_signature(en_events):
            for index, (fr_sig, en_sig) in enumerate(zip(event_signature(fr_events), event_signature(en_events))):
                if fr_sig != en_sig:
                    raise RuntimeError(f"Semantic event alignment differs: {key} event {index}: {fr_sig} != {en_sig}")
            raise RuntimeError(f"Semantic event count differs: {key}")

        row = authority[key]
        observed = [page for _pos, page in fr_pages]
        expected = catalog_pages(row["catalog_pages"])
        if observed != expected:
            residuals.append({
                "id": f"res.auth.{key}", "kind": "authority_metadata",
                "source_id": f"fga.{key}", "reference_id": "", "candidate_ids": "",
                "reason": f"Catalog pages {row['catalog_pages']} differ from direct PDF/TeX pages {','.join(map(str, observed))}.",
                "evidence": f"{row['local_filename']} SHA-256 {row['sha256']}; direct scan controls.",
                "action": "Retain direct-scan page mapping; do not invent a missing page.",
                "status": "OPEN_METADATA_DISCREPANCY",
            })

        fr_text = texts[(key, "fr")]
        en_text = texts[(key, "en")]
        root_type = "erratum" if key.startswith("e") else ("comment" if key == "com" else "expose")
        fr_unit = macro_calls(fr_text, "unit", 1)
        en_unit = macro_calls(en_text, "unit", 1)
        if fr_unit:
            title_fr = plain(fr_unit[0][2][0])
            title_en = plain(en_unit[0][2][0])
        else:
            fr_chapter = macro_calls(fr_text, "chapter*", 1)
            en_chapter = macro_calls(en_text, "chapter*", 1)
            title_fr = plain(fr_chapter[0][2][0]) if fr_chapter else f"Erratum {key[1:]}"
            title_en = plain(en_chapter[0][2][0]) if en_chapter else f"Erratum {key[1:]}"
        root_id = f"fga.{key}"
        root = {
            "id": root_id, "work": "FGA", "item": key, "unit_type": root_type,
            "parent_id": "fga", "ordinal": order_map[key] + 1, "label": key,
            "title_fr": title_fr, "title_en": title_en,
            "summary_fr": "", "summary_en": "",
            "source_start": observed[0], "source_end": observed[-1],
            "numdam_id": row["numdam_id"], "authority_sha256": row["sha256"],
            "fr_file": f"fr/{key}.tex", "fr_line": 1,
            "en_file": f"en/{key}.tex", "en_line": 1,
            "planned_anchor": root_id, "anchor_status": "root_present" if fr_unit else "planned",
            "alignment": "PASS", "provenance_status": "DIRECT_SCAN",
            "_key": key, "_fr_pos": 0, "_en_pos": 0,
            "_fr_end": len(fr_text), "_en_end": len(en_text),
        }
        units.append(root)
        internal[root_id] = root
        for page_index, ((fr_pos, page), (en_pos, en_page)) in enumerate(zip(fr_pages, en_pages), 1):
            if page != en_page:
                raise RuntimeError(f"Page marker differs: {key}")
            unit = {
                "id": f"{root_id}.p{page}", "work": "FGA", "item": key,
                "unit_type": "source_page", "parent_id": root_id, "ordinal": page_index,
                "label": str(page), "title_fr": f"Page source {page}", "title_en": f"Source page {page}",
                "summary_fr": "", "summary_en": "", "source_start": page, "source_end": page,
                "numdam_id": row["numdam_id"], "authority_sha256": row["sha256"],
                "fr_file": f"fr/{key}.tex", "fr_line": line_at(starts[(key, "fr")], fr_pos),
                "en_file": f"en/{key}.tex", "en_line": line_at(starts[(key, "en")], en_pos),
                "planned_anchor": f"{root_id}.p{page}", "anchor_status": "source_marker_present",
                "alignment": "PASS", "provenance_status": "DIRECT_SCAN",
                "_key": key, "_fr_pos": fr_pos, "_en_pos": en_pos,
                "_fr_end": fr_pos + 1, "_en_end": en_pos + 1,
            }
            units.append(unit)
            internal[unit["id"]] = unit

        counters: Counter[tuple[str, str]] = Counter()
        current_section = root_id
        current_result = ""
        event_units: list[dict[str, object]] = []
        section_positions = [event.pos for event in fr_events if "section" in event.kind]
        major_positions = [event.pos for event in fr_events if "section" in event.kind or event.kind in RESULT_TYPES.values() or event.kind == "result"]
        for index, (fr_event, en_event) in enumerate(zip(fr_events, en_events)):
            if "section" in fr_event.kind:
                next_positions = [pos for pos in section_positions if pos > fr_event.pos]
                fr_event.body_end = min(next_positions) if next_positions else len(fr_text)
                en_next = [event.pos for event in en_events[index + 1:] if "section" in event.kind]
                en_event.body_end = min(en_next) if en_next else len(en_text)
                base = "bib" if fr_event.kind == "bibliography_section" else (
                    "add" if fr_event.kind == "supplement_section" else (
                        "s" + slug(fr_event.label) if fr_event.label else "sec." + slug(fr_event.title)
                    )
                )
                counters[(root_id, base)] += 1
                suffix = f".n{counters[(root_id, base)]:02d}" if counters[(root_id, base)] > 1 else ""
                uid = f"{root_id}.{base}{suffix}"
                parent = root_id
                current_section = uid
                current_result = ""
                unit_type = "bibliography" if fr_event.kind == "bibliography_section" else (
                    "supplement" if fr_event.kind == "supplement_section" else "section"
                )
                title_fr_event = fr_event.title
                title_en_event = en_event.title
            elif fr_event.kind in set(RESULT_TYPES.values()) | {"result"}:
                next_major = [pos for pos in major_positions if pos > fr_event.pos]
                fr_event.body_end = min(next_major) if next_major else len(fr_text)
                en_major = [event.pos for event in en_events[index + 1:] if "section" in event.kind or event.kind in set(RESULT_TYPES.values()) | {"result"}]
                en_event.body_end = min(en_major) if en_major else len(en_text)
                label_part = slug(fr_event.label) if fr_event.label else "u"
                base = f"{fr_event.kind}.{label_part}"
                counters[(current_section, base)] += 1
                count = counters[(current_section, base)]
                suffix = f".n{count:02d}" if count > 1 or not fr_event.label else ""
                uid = f"{current_section}.{base}{suffix}"
                parent = current_section
                current_result = uid
                unit_type = fr_event.kind
                fr_name = TYPE_FR.get(unit_type, plain(fr_event.raw_type).title())
                en_name = TYPE_EN.get(unit_type, plain(en_event.raw_type).title())
                title_fr_event = f"{fr_name} {fr_event.label}".strip() + (f" — {fr_event.title}" if fr_event.title else "")
                title_en_event = f"{en_name} {en_event.label}".strip() + (f" — {en_event.title}" if en_event.title else "")
            else:
                fr_event.body_end = fr_event.end
                en_event.body_end = en_event.end
                parent = current_result or current_section or root_id
                if fr_event.kind == "equation":
                    base = "eq." + (slug(fr_event.label) if fr_event.label else "u")
                    title_fr_event = "Équation" + (f" {fr_event.label}" if fr_event.label else " non numérotée")
                    title_en_event = "Equation" + (f" {en_event.label}" if en_event.label else " unnumbered")
                    unit_type = "equation"
                elif fr_event.kind == "diagram":
                    base = "diag"
                    title_fr_event = "Diagramme TeX natif"
                    title_en_event = "Native TeX diagram"
                    unit_type = "diagram"
                elif fr_event.kind == "bibliography_item" or internal.get(current_section, {}).get("unit_type") == "bibliography":
                    base = "ref." + (slug(fr_event.label) if fr_event.label else "u")
                    title_fr_event = f"Référence [{fr_event.label}]" if fr_event.label else "Référence"
                    title_en_event = f"Reference [{en_event.label}]" if en_event.label else "Reference"
                    unit_type = "bibliography_item"
                else:
                    base = "item." + (slug(fr_event.label) if fr_event.label else "u")
                    title_fr_event = fr_event.title or (f"Sous-item {fr_event.label}" if fr_event.label else "Sous-item")
                    title_en_event = en_event.title or (f"Subitem {en_event.label}" if en_event.label else "Subitem")
                    unit_type = "subitem"
                counters[(parent, base)] += 1
                count = counters[(parent, base)]
                suffix = f".n{count:02d}" if count > 1 or base.endswith(".u") or base == "diag" else ""
                uid = f"{parent}.{base}{suffix}"
            fr_event.uid = uid
            fr_event.parent = parent
            en_event.uid = uid
            en_event.parent = parent
            fr_start_page, fr_end_page = source_span(fr_pages, fr_event.pos, max(fr_event.body_end, fr_event.end))
            en_start_page, en_end_page = source_span(en_pages, en_event.pos, max(en_event.body_end, en_event.end))
            if (fr_start_page, fr_end_page) != (en_start_page, en_end_page):
                raise RuntimeError(f"Unit source span differs: {uid}")
            unit = {
                "id": uid, "work": "FGA", "item": key, "unit_type": unit_type,
                "parent_id": parent, "ordinal": index + 1, "label": fr_event.label,
                "title_fr": title_fr_event, "title_en": title_en_event,
                "summary_fr": snippet(fr_text, fr_event.end, fr_event.body_end),
                "summary_en": snippet(en_text, en_event.end, en_event.body_end),
                "source_start": fr_start_page, "source_end": fr_end_page,
                "numdam_id": row["numdam_id"], "authority_sha256": row["sha256"],
                "fr_file": f"fr/{key}.tex", "fr_line": line_at(starts[(key, "fr")], fr_event.pos),
                "en_file": f"en/{key}.tex", "en_line": line_at(starts[(key, "en")], en_event.pos),
                "planned_anchor": uid, "anchor_status": "planned",
                "alignment": "PASS", "provenance_status": "DIRECT_SCAN",
                "_key": key, "_fr_pos": fr_event.pos, "_en_pos": en_event.pos,
                "_fr_end": fr_event.body_end, "_en_end": en_event.body_end,
            }
            if uid in internal:
                prior = internal[uid]
                raise RuntimeError(
                    f"Duplicate semantic ID while building {key} event {index}: {uid}; "
                    f"prior={prior.get('unit_type')} {prior.get('label')}"
                )
            units.append(unit)
            internal[uid] = unit
            event_units.append(unit)

    if len({row["id"] for row in units}) != len(units):
        duplicates = [key for key, count in Counter(row["id"] for row in units).items() if count > 1]
        raise RuntimeError(f"Duplicate semantic IDs: {duplicates[:10]}")
    valid_internal = set(internal) | {"fga"}
    if any(row["parent_id"] not in valid_internal for row in units):
        raise RuntimeError("Semantic parent is absent")

    targets: list[dict[str, object]] = []
    targets.append({
        "target_id": "fga", "target_type": "corpus", "display_fr": "Fondements de la géométrie algébrique",
        "display_en": "Foundations of Algebraic Geometry", "scope": "corpus", "item": "",
        "label": "FGA", "source_pages": "", "authority": "17 frozen NUMDAM witnesses",
    })
    for row in units:
        targets.append({
            "target_id": row["id"], "target_type": row["unit_type"],
            "display_fr": row["title_fr"], "display_en": row["title_en"],
            "scope": "internal", "item": row["item"], "label": row["label"],
            "source_pages": f"{row['source_start']}--{row['source_end']}",
            "authority": f"{row['numdam_id']} {row['authority_sha256']}",
        })
    for siglum, (target_id, title) in EXTERNAL.items():
        targets.append({
            "target_id": target_id, "target_type": "external_work", "display_fr": title,
            "display_en": title, "scope": "external", "item": "", "label": siglum,
            "source_pages": "", "authority": "Named in FGA; external identity not asserted here",
        })

    lookups: defaultdict[tuple[str, str, str], list[str]] = defaultdict(list)
    generic: defaultdict[tuple[str, str], list[str]] = defaultdict(list)
    bib: dict[tuple[str, str], str] = {}
    for row in units:
        label = slug(str(row["label"])) if row["label"] else ""
        if label:
            lookups[(str(row["item"]), str(row["unit_type"]), label)].append(str(row["id"]))
            if row["unit_type"] in {"section", "theorem", "proposition", "corollary", "lemma", "definition", "remark", "equation"}:
                generic[(str(row["item"]), label)].append(str(row["id"]))
            if row["unit_type"] == "bibliography_item":
                bib[(str(row["item"]), label)] = str(row["id"])

    def containing(key: str, lang: str, pos: int) -> dict[str, object]:
        candidates = [
            row for row in units if row["_key"] == key and row["unit_type"] != "source_page"
            and int(row[f"_{lang}_pos"]) <= pos < int(row[f"_{lang}_end"])
        ]
        if not candidates:
            return internal[f"fga.{key}"]
        return min(candidates, key=lambda row: int(row[f"_{lang}_end"]) - int(row[f"_{lang}_pos"]))

    refs: list[dict[str, object]] = []
    candidates: list[dict[str, object]] = []
    edges: list[dict[str, object]] = []
    ref_seq = 0
    edge_seq = 0

    def add_edge(source: str, relation: str, target: str, confidence: str, evidence: str, provenance: str) -> None:
        nonlocal edge_seq
        edge_seq += 1
        edges.append({
            "edge_id": f"edge.{edge_seq:06d}", "source_id": source, "relation": relation,
            "target_id": target, "confidence": confidence, "evidence": evidence,
            "provenance": provenance, "official_stacks_tag": "",
        })

    for row in units:
        add_edge(str(row["parent_id"]), "contains", str(row["id"]), "high", "TeX hierarchy and direct source order", f"{row['fr_file']}:{row['fr_line']}")

    manual_edges = []
    for expose in ("149", "182", "190", "195", "212", "221", "232", "236"):
        manual_edges.append((f"fga.e{expose}", "corrects_or_supplements", f"fga.{expose}", "Linked item-level erratum authority"))
        manual_edges.append(("fga.com", "contextualizes", f"fga.{expose}", "Commentaires p.297 states that the eight exposés are gathered together"))
    manual_edges.extend([
        ("fga.195", "continues", "fga.190", "TDTE II follows TDTE I"),
        ("fga.212", "continues", "fga.195", "Construction/existence sequence III follows II"),
        ("fga.221", "continues", "fga.212", "Construction/existence sequence IV follows III"),
        ("fga.232", "continues", "fga.221", "TDTE V follows IV"),
        ("fga.236", "continues", "fga.232", "Section 0 explicitly gives complements to the preceding exposé"),
        ("fga.190", "methodological_basis_for", "fga.195", "Faithfully flat descent underlies formal existence"),
        ("fga.190", "methodological_basis_for", "fga.212", "Descent framework underlies quotient preschemes"),
        ("fga.221", "methodological_basis_for", "fga.232", "Hilbert schemes are used in Picard representability"),
        ("fga.232", "methodological_basis_for", "fga.236", "Picard existence precedes general Picard properties"),
    ])
    for source, relation, target, evidence in manual_edges:
        add_edge(source, relation, target, "high", evidence, "Direct titles, Commentaires, or explicit internal reference")

    word_map = {
        "théorème": "theorem", "theorem": "theorem", "proposition": "proposition",
        "corollaire": "corollary", "corollary": "corollary", "lemme": "lemma", "lemma": "lemma",
        "remarque": "remark", "remark": "remark", "définition": "definition", "definition": "definition",
        "section": "section", "paragraphe": "section", "équation": "equation", "equation": "equation",
        "formule": "equation", "formula": "equation",
    }

    for key in KEYS:
        for lang in ("fr", "en"):
            text = texts[(key, lang)]
            line_index = starts[(key, lang)]
            seen: set[tuple[int, int, str]] = set()

            def record(start: int, end: int, raw: str, kind: str, target_ids: list[str]) -> None:
                nonlocal ref_seq
                marker = (start, end, kind)
                if marker in seen:
                    return
                seen.add(marker)
                source = containing(key, lang, start)
                if source["unit_type"] == "bibliography_item" and kind not in {"siglum", "expose"}:
                    return
                unique_targets = list(dict.fromkeys(target_ids))
                status = "RESOLVED" if len(unique_targets) == 1 else ("AMBIGUOUS" if unique_targets else "UNRESOLVED")
                ref_seq += 1
                ref_id = f"ref.{lang}.{ref_seq:06d}"
                refs.append({
                    "ref_id": ref_id, "language": lang, "source_unit": source["id"],
                    "file": f"{lang}/{key}.tex", "line": line_at(line_index, start),
                    "raw": plain(raw), "ref_kind": kind, "status": status,
                    "selected_target": unique_targets[0] if len(unique_targets) == 1 else "",
                    "candidate_count": len(unique_targets),
                })
                for rank, target in enumerate(unique_targets, 1):
                    candidates.append({
                        "ref_id": ref_id, "candidate_rank": rank, "candidate_id": target,
                        "basis": "same-item label/type or explicit corpus/external siglum",
                        "selected": "yes" if len(unique_targets) == 1 else "no",
                    })
                if len(unique_targets) == 1:
                    add_edge(str(source["id"]), "references", unique_targets[0], "high", plain(raw), f"{lang}/{key}.tex:{line_at(line_index, start)}")
                else:
                    residuals.append({
                        "id": f"res.{ref_id}", "kind": "reference_resolution",
                        "source_id": source["id"], "reference_id": ref_id,
                        "candidate_ids": ";".join(unique_targets),
                        "reason": "More than one target fits the printed label." if unique_targets else "No local or declared external target fits the printed reference.",
                        "evidence": f"{lang}/{key}.tex:{line_at(line_index, start)} {plain(raw)}",
                        "action": "Human mathematical resolution; do not guess.", "status": status,
                    })

            for match in re.finditer(r"(?<!\\)\[([0-9]{1,2})\]", text):
                target = bib.get((key, slug(match.group(1))))
                record(match.start(), match.end(), match.group(0), "bibliography", [target] if target else [])
            explicit = re.compile(
                r"\b(théorème|theorem|proposition|corollaire|corollary|lemme|lemma|remarque|remark|définition|definition|section|paragraphe|équation|equation|formule|formula)\s*\(?\s*([0-9]+(?:\.[0-9]+)?(?:\s*bis)?)",
                re.I,
            )
            for match in explicit.finditer(text):
                unit_type = word_map[match.group(1).casefold()]
                ids = lookups.get((key, unit_type, slug(match.group(2))), [])
                record(match.start(), match.end(), match.group(0), f"explicit_{unit_type}", list(ids))
            for match in re.finditer(r"\(([0-9]+\.[0-9]+(?:\s*bis)?)\)", text):
                record(match.start(), match.end(), match.group(0), "numeric_label", list(generic.get((key, slug(match.group(1))), [])))
            for siglum, (target, _title) in EXTERNAL.items():
                for match in re.finditer(r"\b" + siglum + r"\b", text):
                    record(match.start(), match.end(), match.group(0), "siglum", [target])
            for match in re.finditer(r"[Ee]xpos[ée][^0-9\n]{0,28}([0-9]{3})", text):
                number = match.group(1)
                target = f"fga.{number}"
                record(match.start(), match.end(), match.group(0), "expose", [target] if target in internal else [])

    concepts: list[dict[str, object]] = []
    term_rows: list[dict[str, object]] = []
    concept_units: defaultdict[str, list[str]] = defaultdict(list)
    concept_counts: Counter[str] = Counter()
    scan_types = {"expose", "erratum", "comment", "section", "supplement", "theorem", "proposition", "corollary", "lemma", "definition", "remark"}
    for concept_id, label, fr_pattern, en_pattern in CONCEPTS:
        target_id = f"concept.{concept_id}"
        concepts.append({
            "concept_id": concept_id, "label": label, "description": f"Internal FGA migration topic: {label}.",
            "fr_pattern": fr_pattern, "en_pattern": en_pattern, "target_id": target_id,
        })
        targets.append({
            "target_id": target_id, "target_type": "concept", "display_fr": label,
            "display_en": label, "scope": "internal_vocabulary", "item": "", "label": concept_id,
            "source_pages": "", "authority": "Derived only from direct FGA text occurrences",
        })
        for unit in units:
            if unit["unit_type"] not in scan_types:
                continue
            key = str(unit["_key"])
            fr_body = plain(texts[(key, "fr")][int(unit["_fr_pos"]):int(unit["_fr_end"])])
            en_body = plain(texts[(key, "en")][int(unit["_en_pos"]):int(unit["_en_end"])])
            fr_hits = list(re.finditer(fr_pattern, fr_body, re.I))
            en_hits = list(re.finditer(en_pattern, en_body, re.I))
            if not fr_hits and not en_hits:
                continue
            first_text = fr_body if fr_hits else en_body
            first = (fr_hits or en_hits)[0]
            evidence = first_text[max(0, first.start() - 55):min(len(first_text), first.end() + 95)]
            term_rows.append({
                "concept_id": concept_id, "unit_id": unit["id"], "item": unit["item"],
                "unit_type": unit["unit_type"], "fr_count": len(fr_hits), "en_count": len(en_hits),
                "source_pages": f"{unit['source_start']}--{unit['source_end']}",
                "evidence": evidence, "scope": "aggregate" if unit["unit_type"] in {"expose", "erratum", "comment", "section", "supplement"} else "precise",
            })
            concept_units[concept_id].append(str(unit["id"]))
            concept_counts[concept_id] += max(len(fr_hits), len(en_hits))
            add_edge(str(unit["id"]), "about", target_id, "medium", evidence, f"Direct cross-language text match, pages {unit['source_start']}--{unit['source_end']}")
        if not concept_units[concept_id]:
            residuals.append({
                "id": f"res.concept.{concept_id}", "kind": "concept_vocabulary",
                "source_id": "fga", "reference_id": "", "candidate_ids": target_id,
                "reason": "Declared vocabulary topic has no detected occurrence.",
                "evidence": f"Patterns: {fr_pattern} | {en_pattern}",
                "action": "Review vocabulary or source spelling.", "status": "UNRESOLVED",
            })

    stacks: list[dict[str, object]] = []
    for concept_id, label, _fr_pattern, _en_pattern in CONCEPTS:
        ids = list(dict.fromkeys(concept_units[concept_id]))
        pages = sorted({
            int(internal[uid]["source_start"]) for uid in ids if uid in internal
        })
        count = concept_counts[concept_id]
        confidence = "high" if count >= 8 else ("medium" if count else "low")
        stacks.append({
            "candidate_id": f"pre.{concept_id}", "concept_id": concept_id,
            "candidate_topic": label, "relation": "historical_precursor_or_overlap",
            "confidence": confidence, "evidence_units": ";".join(ids[:16]),
            "evidence_pages": ";".join(map(str, pages[:24])),
            "official_tag": "", "tag_status": "UNASSIGNED",
            "justification": "Internal migration topic only; no official Stacks tag asserted or invented.",
        })
    residuals.append({
        "id": "res.stacks.tags", "kind": "pre_stacks_policy", "source_id": "fga",
        "reference_id": "", "candidate_ids": ";".join(row["candidate_id"] for row in stacks),
        "reason": "Official Stacks tags intentionally remain unassigned.",
        "evidence": "Every official_tag field in stacks.csv is blank.",
        "action": "A later authorized mapping pass must verify official tags directly.",
        "status": "INTENTIONAL_UNASSIGNED",
    })

    target_ids = {str(row["target_id"]) for row in targets}
    if len(target_ids) != len(targets):
        raise RuntimeError("Duplicate target IDs")
    if any(str(row["source_id"]) not in target_ids or str(row["target_id"]) not in target_ids for row in edges):
        bad = [row for row in edges if str(row["source_id"]) not in target_ids or str(row["target_id"]) not in target_ids]
        raise RuntimeError(f"Graph edge endpoint absent: {bad[:3]}")
    if any(row["official_tag"] for row in stacks) or any(row["official_stacks_tag"] for row in edges):
        raise RuntimeError("An official Stacks tag was asserted")
    unresolved_refs = {str(row["ref_id"]) for row in refs if row["status"] != "RESOLVED"}
    residual_refs = {str(row["reference_id"]) for row in residuals if row["reference_id"]}
    if unresolved_refs != residual_refs:
        raise RuntimeError("Reference residual closure differs")

    public_unit_fields = [
        "id", "work", "item", "unit_type", "parent_id", "ordinal", "label",
        "title_fr", "title_en", "summary_fr", "summary_en", "source_start", "source_end",
        "numdam_id", "authority_sha256", "fr_file", "fr_line", "en_file", "en_line",
        "planned_anchor", "anchor_status", "alignment", "provenance_status",
    ]
    save_csv(ED / "units.csv", units, public_unit_fields)
    save_csv(ED / "targets.csv", targets, [
        "target_id", "target_type", "display_fr", "display_en", "scope", "item", "label", "source_pages", "authority",
    ])
    save_csv(ED / "refs.csv", refs, [
        "ref_id", "language", "source_unit", "file", "line", "raw", "ref_kind", "status", "selected_target", "candidate_count",
    ])
    save_csv(ED / "cands.csv", candidates, ["ref_id", "candidate_rank", "candidate_id", "basis", "selected"])
    save_csv(ED / "edges.csv", edges, [
        "edge_id", "source_id", "relation", "target_id", "confidence", "evidence", "provenance", "official_stacks_tag",
    ])
    save_csv(ED / "resid.csv", residuals, [
        "id", "kind", "source_id", "reference_id", "candidate_ids", "reason", "evidence", "action", "status",
    ])
    save_csv(ED / "concepts.csv", concepts, ["concept_id", "label", "description", "fr_pattern", "en_pattern", "target_id"])
    save_csv(ED / "terms.csv", term_rows, [
        "concept_id", "unit_id", "item", "unit_type", "fr_count", "en_count", "source_pages", "evidence", "scope",
    ])
    save_csv(ED / "stacks.csv", stacks, [
        "candidate_id", "concept_id", "candidate_topic", "relation", "confidence", "evidence_units", "evidence_pages",
        "official_tag", "tag_status", "justification",
    ])

    graph_nodes = [{key: value for key, value in row.items()} for row in targets]
    graph_edges = [{key: value for key, value in row.items()} for row in edges]
    save_json(ED / "graph.json", {
        "schema": "fga-pre-stacks-graph-1", "corpus": "FGA",
        "languages": ["fr", "en"], "shared_semantic_graph": True,
        "official_stacks_tags_asserted": 0, "nodes": graph_nodes, "edges": graph_edges,
    })

    by_key: defaultdict[str, list[dict[str, object]]] = defaultdict(list)
    for row in units:
        by_key[str(row["item"])].append(row)
    lines = [
        "# FGA semantic index", "",
        "This index covers the two separate language editions through one shared semantic graph.",
        "Official Stacks tags are intentionally unassigned; `stacks.csv` contains internal migration topics only.", "",
        "## Global contents", "",
    ]
    for key in KEYS:
        root = internal[f"fga.{key}"]
        rows = by_key[key]
        counts = Counter(str(row["unit_type"]) for row in rows)
        lines.append(f"- `{root['id']}` — {root['title_en']} (source pp. {root['source_start']}–{root['source_end']}; "
                     f"{counts['section']} sections, {sum(counts[t] for t in RESULT_TYPES.values())} results, "
                     f"{counts['equation']} equation blocks, {counts['diagram']} native-TeX diagrams, "
                     f"{counts['bibliography_item']} bibliography entries)")
        for section in [row for row in rows if row["unit_type"] in {"section", "supplement", "bibliography"}]:
            lines.append(f"  - `{section['id']}` — {section['title_en']} (pp. {section['source_start']}–{section['source_end']})")
    lines.extend(["", "## Concept index", ""])
    for concept_id, label, _fr, _en in sorted(CONCEPTS, key=lambda row: row[1].casefold()):
        ids = list(dict.fromkeys(concept_units[concept_id]))
        shown = ", ".join(f"`{uid}`" for uid in ids[:8])
        if len(ids) > 8:
            shown += f", … (+{len(ids) - 8})"
        lines.append(f"- **{label}** — {concept_counts[concept_id]} detected occurrences; {shown or 'no detected unit'}")
    lines.extend([
        "", "## Reference closure", "",
        f"- Reference occurrences: {len(refs)}",
        f"- Resolved: {sum(row['status'] == 'RESOLVED' for row in refs)}",
        f"- Ambiguous: {sum(row['status'] == 'AMBIGUOUS' for row in refs)}",
        f"- Unresolved: {sum(row['status'] == 'UNRESOLVED' for row in refs)}",
        f"- Residual rows (including authority/policy residuals): {len(residuals)}",
        "", "Machine-readable closure is in `targets.csv`, `refs.csv`, `cands.csv`, `edges.csv`, and `resid.csv`.",
    ])
    save_text(ED / "index.md", "\n".join(lines) + "\n")

    head = subprocess.run(
        ["git", "-C", str(ROOT.parents[4]), "rev-parse", "HEAD"],
        check=True, capture_output=True, text=True,
    ).stdout.strip()
    output_names = [
        "units.csv", "targets.csv", "refs.csv", "cands.csv", "edges.csv", "resid.csv",
        "concepts.csv", "terms.csv", "stacks.csv", "graph.json", "index.md",
    ]
    counts = Counter(str(row["unit_type"]) for row in units)
    validation = {
        "schema": "fga-semantic-validation-1", "status": "PASS", "errors": [],
        "producer_commit": head, "authority_manifest_sha256": AUTH_MANIFEST_SHA256,
        "authority_validation_sha256": AUTH_VALIDATION_SHA256, "authority_files_rehashed": 17,
        "language_files": {"fr": 17, "en": 17}, "language_event_alignment": "PASS",
        "source_page_alignment": "PASS", "unique_unit_ids": True, "parent_closure": True,
        "unit_counts": dict(sorted(counts.items())), "targets": len(targets), "references": len(refs),
        "resolved_references": sum(row["status"] == "RESOLVED" for row in refs),
        "ambiguous_references": sum(row["status"] == "AMBIGUOUS" for row in refs),
        "unresolved_references": sum(row["status"] == "UNRESOLVED" for row in refs),
        "candidate_rows": len(candidates), "edges": len(edges), "residuals": len(residuals),
        "concepts": len(concepts), "term_links": len(term_rows), "pre_stacks_candidates": len(stacks),
        "official_stacks_tags_asserted": 0, "privacy_paths_emitted": 0,
        "files": [
            {"name": name, "bytes": (ED / name).stat().st_size, "sha256": sha256(ED / name)}
            for name in output_names
        ],
    }
    save_json(ED / "sem.json", validation)
    print(json.dumps(validation, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
